"""
五子棋AI难度系统模块
实现不同难度级别的AI策略算法
"""

from __future__ import annotations

from typing import List, Tuple, Optional, Dict
from enum import Enum
import random
from .gomoku_game import GomokuBoard, Player, get_current_board


class DifficultyLevel(Enum):
    """难度级别枚举"""
    BEGINNER = "beginner"      # 初级：随机走法，偶尔防守
    INTERMEDIATE = "intermediate"  # 中级：BFS/DFS，深度=2
    ADVANCE = "advance"        # 高级：深度=4，Alpha-Beta剪枝
    EXPERT = "expert"          # 专家：深度搜索+高级评估


class AIDifficultyEngine:
    """AI难度引擎，根据难度级别选择不同的策略"""
    
    def __init__(self, difficulty: DifficultyLevel = DifficultyLevel.INTERMEDIATE):
        """
        初始化AI难度引擎
        
        Args:
            difficulty: 难度级别
        """
        self.difficulty = difficulty
        self.evaluation_cache: Dict[str, float] = {}
    
    def get_best_move(self, board: GomokuBoard) -> Optional[Tuple[int, int]]:
        """
        根据难度级别获取最佳走法
        
        Args:
            board: 当前棋盘状态
            
        Returns:
            最佳走法坐标 (row, col)，如果无有效走法则返回None
        """
        if board.game_over:
            return None
        
        # 检查是否有必胜走法（所有难度都应该优先选择）
        winning_move = self._find_winning_move(board)
        if winning_move:
            return winning_move
        
        # 检查是否需要防守（阻止对方获胜）
        blocking_move = self._find_blocking_move(board)
        
        # 根据难度级别选择策略
        if self.difficulty == DifficultyLevel.BEGINNER:
            return self._beginner_strategy(board, blocking_move)
        elif self.difficulty == DifficultyLevel.INTERMEDIATE:
            return self._intermediate_strategy(board, blocking_move)
        elif self.difficulty == DifficultyLevel.ADVANCE:
            return self._advance_strategy(board, blocking_move)
        elif self.difficulty == DifficultyLevel.EXPERT:
            return self._expert_strategy(board, blocking_move)
        else:
            return self._intermediate_strategy(board, blocking_move)
    
    def _beginner_strategy(self, board: GomokuBoard, blocking_move: Optional[Tuple[int, int]]) -> Optional[Tuple[int, int]]:
        """
        初级策略：随机走法，30%概率防守
        
        Args:
            board: 当前棋盘
            blocking_move: 防守走法（如果有）
            
        Returns:
            选择的走法
        """
        # 30%概率防守
        if blocking_move and random.random() < 0.3:
            return blocking_move
        
        # 70%概率随机走法
        valid_moves = self._get_valid_moves(board)
        if not valid_moves:
            return None
        
        # 优先选择中心区域（稍微智能一点）
        center = board.size // 2
        center_moves = [
            (r, c) for r, c in valid_moves
            if abs(r - center) <= 3 and abs(c - center) <= 3
        ]
        
        if center_moves:
            return random.choice(center_moves)
        else:
            return random.choice(valid_moves)
    
    def _intermediate_strategy(self, board: GomokuBoard, blocking_move: Optional[Tuple[int, int]]) -> Optional[Tuple[int, int]]:
        """
        中级策略：Minimax算法，深度=2
        
        Args:
            board: 当前棋盘
            blocking_move: 防守走法（如果有）
            
        Returns:
            选择的走法
        """
        # 优先防守
        if blocking_move:
            return blocking_move
        
        # 使用Minimax搜索，深度=2
        depth = 2
        best_move, _ = self._minimax(board, depth, True, float('-inf'), float('inf'))
        return best_move
    
    def _advance_strategy(self, board: GomokuBoard, blocking_move: Optional[Tuple[int, int]]) -> Optional[Tuple[int, int]]:
        """
        高级策略：Minimax + Alpha-Beta剪枝，深度=4
        
        Args:
            board: 当前棋盘
            blocking_move: 防守走法（如果有）
            
        Returns:
            选择的走法
        """
        # 优先防守
        if blocking_move:
            return blocking_move
        
        # 使用Alpha-Beta剪枝的Minimax，深度=4
        depth = 4
        best_move, _ = self._minimax(board, depth, True, float('-inf'), float('inf'))
        return best_move
    
    def _expert_strategy(self, board: GomokuBoard, blocking_move: Optional[Tuple[int, int]]) -> Optional[Tuple[int, int]]:
        """
        专家策略：深度搜索（深度=6）+ 高级评估函数
        
        Args:
            board: 当前棋盘
            blocking_move: 防守走法（如果有）
            
        Returns:
            选择的走法
        """
        # 优先防守
        if blocking_move:
            return blocking_move
        
        # 使用更深的搜索，深度=6
        depth = 6
        best_move, _ = self._minimax(board, depth, True, float('-inf'), float('inf'))
        return best_move
    
    def _minimax(
        self,
        board: GomokuBoard,
        depth: int,
        maximizing: bool,
        alpha: float,
        beta: float
    ) -> Tuple[Optional[Tuple[int, int]], float]:
        """
        Minimax算法（带Alpha-Beta剪枝）
        
        Args:
            board: 当前棋盘状态
            depth: 搜索深度
            maximizing: 是否为最大化玩家（当前玩家）
            alpha: Alpha值（用于剪枝）
            beta: Beta值（用于剪枝）
            
        Returns:
            (最佳走法, 评估分数)
        """
        # 检查游戏是否结束
        if board.game_over:
            if board.winner == board.current_player:
                return None, 10000  # 当前玩家获胜
            elif board.winner:
                return None, -10000  # 对手获胜
            else:
                return None, 0  # 平局
        
        # 达到最大深度，使用评估函数
        if depth == 0:
            score = self._evaluate_position(board)
            return None, score
        
        valid_moves = self._get_valid_moves(board)
        if not valid_moves:
            return None, 0
        
        best_move = None
        best_score = float('-inf') if maximizing else float('inf')
        
        # 对走法进行排序（启发式排序，提高剪枝效率）
        sorted_moves = self._sort_moves(board, valid_moves)
        
        for move in sorted_moves:
            # 创建新棋盘状态
            new_board = self._make_move_on_copy(board, move)
            
            # 递归搜索
            _, score = self._minimax(new_board, depth - 1, not maximizing, alpha, beta)
            
            # 更新最佳走法
            if maximizing:
                if score > best_score:
                    best_score = score
                    best_move = move
                alpha = max(alpha, best_score)
            else:
                if score < best_score:
                    best_score = score
                    best_move = move
                beta = min(beta, best_score)
            
            # Alpha-Beta剪枝
            if beta <= alpha:
                break
        
        return best_move, best_score
    
    def _evaluate_position(self, board: GomokuBoard) -> float:
        """
        评估当前局面的分数
        
        Args:
            board: 当前棋盘
            
        Returns:
            评估分数（正数表示对当前玩家有利）
        """
        current_player = board.current_player
        opponent = Player.WHITE if current_player == Player.BLACK else Player.BLACK
        
        # 评估当前玩家的优势
        my_score = self._evaluate_player_position(board, current_player)
        # 评估对手的优势
        opponent_score = self._evaluate_player_position(board, opponent)
        
        return my_score - opponent_score
    
    def _evaluate_player_position(self, board: GomokuBoard, player: Player) -> float:
        """
        评估特定玩家的局面优势
        
        Args:
            board: 当前棋盘
            player: 要评估的玩家
            
        Returns:
            评估分数
        """
        score = 0.0
        size = board.size
        
        # 检查每个方向的连续棋子
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        
        for i in range(size):
            for j in range(size):
                if board.board[i][j] == player:
                    # 检查每个方向的模式
                    for dr, dc in directions:
                        pattern_score = self._evaluate_pattern(board, i, j, dr, dc, player)
                        score += pattern_score
        
        return score
    
    def _evaluate_pattern(
        self,
        board: GomokuBoard,
        row: int,
        col: int,
        dr: int,
        dc: int,
        player: Player
    ) -> float:
        """
        评估特定位置的模式分数
        
        Args:
            board: 当前棋盘
            row: 行坐标
            col: 列坐标
            dr: 行方向增量
            dc: 列方向增量
            player: 玩家
            
        Returns:
            模式分数
        """
        count = 1  # 当前位置
        blocked_ends = 0  # 被阻挡的端点数量
        
        # 正向计数
        for i in range(1, 5):
            nr, nc = row + dr * i, col + dc * i
            if 0 <= nr < board.size and 0 <= nc < board.size:
                if board.board[nr][nc] == player:
                    count += 1
                elif board.board[nr][nc] != Player.EMPTY:
                    blocked_ends += 1
                    break
            else:
                blocked_ends += 1
                break
        
        # 反向计数
        for i in range(1, 5):
            nr, nc = row - dr * i, col - dc * i
            if 0 <= nr < board.size and 0 <= nc < board.size:
                if board.board[nr][nc] == player:
                    count += 1
                elif board.board[nr][nc] != Player.EMPTY:
                    blocked_ends += 1
                    break
            else:
                blocked_ends += 1
                break
        
        # 根据连续数量和开放端点计算分数
        if count >= 5:
            return 10000  # 五连
        elif count == 4:
            if blocked_ends == 0:
                return 1000  # 活四
            elif blocked_ends == 1:
                return 100  # 冲四
        elif count == 3:
            if blocked_ends == 0:
                return 50  # 活三
            elif blocked_ends == 1:
                return 10  # 眠三
        elif count == 2:
            if blocked_ends == 0:
                return 5  # 活二
            elif blocked_ends == 1:
                return 1  # 眠二
        
        return 0
    
    def _sort_moves(self, board: GomokuBoard, moves: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
        """
        对走法进行启发式排序（提高搜索效率）
        
        Args:
            board: 当前棋盘
            moves: 待排序的走法列表
            
        Returns:
            排序后的走法列表
        """
        # 计算每个走法的启发式分数
        move_scores = []
        for move in moves:
            score = self._heuristic_score(board, move)
            move_scores.append((move, score))
        
        # 按分数降序排序
        move_scores.sort(key=lambda x: x[1], reverse=True)
        return [move for move, _ in move_scores]
    
    def _heuristic_score(self, board: GomokuBoard, move: Tuple[int, int]) -> float:
        """
        计算走法的启发式分数
        
        Args:
            board: 当前棋盘
            move: 走法坐标
            
        Returns:
            启发式分数
        """
        row, col = move
        score = 0.0
        
        # 优先选择中心区域
        center = board.size // 2
        distance_from_center = abs(row - center) + abs(col - center)
        score += (board.size - distance_from_center) * 0.1
        
        # 优先选择靠近已有棋子的位置
        for i in range(max(0, row - 2), min(board.size, row + 3)):
            for j in range(max(0, col - 2), min(board.size, col + 3)):
                if (i, j) != (row, col) and board.board[i][j] != Player.EMPTY:
                    score += 1.0
        
        return score
    
    def _get_valid_moves(self, board: GomokuBoard) -> List[Tuple[int, int]]:
        """
        获取所有有效走法
        
        Args:
            board: 当前棋盘
            
        Returns:
            有效走法列表
        """
        valid_moves = []
        for i in range(board.size):
            for j in range(board.size):
                if board.is_valid_move(i, j):
                    valid_moves.append((i, j))
        return valid_moves
    
    def _make_move_on_copy(self, board: GomokuBoard, move: Tuple[int, int]) -> GomokuBoard:
        """
        在棋盘副本上执行走法（不修改原棋盘）
        
        Args:
            board: 原棋盘
            move: 走法坐标
            
        Returns:
            新的棋盘副本
        """
        new_board = GomokuBoard(board.size)
        # 复制棋盘状态
        for i in range(board.size):
            for j in range(board.size):
                new_board.board[i][j] = board.board[i][j]
        new_board.current_player = board.current_player
        new_board.move_history = board.move_history.copy()
        new_board.game_over = board.game_over
        new_board.winner = board.winner
        
        # 执行走法
        row, col = move
        new_board.make_move(row, col)
        return new_board
    
    def _find_winning_move(self, board: GomokuBoard) -> Optional[Tuple[int, int]]:
        """
        查找必胜走法（当前玩家可以立即获胜）
        
        Args:
            board: 当前棋盘
            
        Returns:
            必胜走法，如果没有则返回None
        """
        valid_moves = self._get_valid_moves(board)
        for move in valid_moves:
            test_board = self._make_move_on_copy(board, move)
            if test_board.game_over and test_board.winner == board.current_player:
                return move
        return None
    
    def _find_blocking_move(self, board: GomokuBoard) -> Optional[Tuple[int, int]]:
        """
        查找防守走法（阻止对手立即获胜）
        
        Args:
            board: 当前棋盘
            
        Returns:
            防守走法，如果没有则返回None
        """
        opponent = Player.WHITE if board.current_player == Player.BLACK else Player.BLACK
        valid_moves = self._get_valid_moves(board)
        
        for move in valid_moves:
            # 检查如果对手走这里是否会获胜
            # 创建测试棋盘
            test_board = GomokuBoard(board.size)
            # 复制棋盘状态
            for i in range(board.size):
                for j in range(board.size):
                    test_board.board[i][j] = board.board[i][j]
            test_board.current_player = opponent
            test_board.move_history = board.move_history.copy()
            
            # 临时放置对手的棋子
            row, col = move
            test_board.board[row][col] = opponent
            # 检查是否形成五连
            if test_board._check_win(row, col):
                return move
        return None


def get_ai_move(difficulty: str = "intermediate") -> str:
    """
    获取AI走法（作为工具函数供Agent调用）
    
    Args:
        difficulty: 难度级别 ("beginner", "intermediate", "advance", "expert")
        
    Returns:
        走法字符串，格式为 "row,col" 或错误信息
    """
    try:
        # 将字符串转换为枚举
        difficulty_map = {
            "beginner": DifficultyLevel.BEGINNER,
            "intermediate": DifficultyLevel.INTERMEDIATE,
            "advance": DifficultyLevel.ADVANCE,
            "expert": DifficultyLevel.EXPERT,
        }
        
        if difficulty.lower() not in difficulty_map:
            return f"错误：无效的难度级别 '{difficulty}'。支持的难度：beginner, intermediate, advance, expert"
        
        level = difficulty_map[difficulty.lower()]
        board = get_current_board()
        
        if board.game_over:
            return "游戏已结束，无法获取AI走法"
        
        engine = AIDifficultyEngine(level)
        best_move = engine.get_best_move(board)
        
        if best_move is None:
            return "错误：无法找到有效走法"
        
        row, col = best_move
        return f"{row},{col}"
        
    except Exception as e:
        return f"获取AI走法失败: {str(e)}"

